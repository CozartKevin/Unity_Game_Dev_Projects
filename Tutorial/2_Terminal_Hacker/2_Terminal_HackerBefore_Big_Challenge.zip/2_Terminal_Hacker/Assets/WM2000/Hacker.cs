﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hacker : MonoBehaviour {

    int level;
    enum Screen { MainMenu, Password, Win};
    Screen currentScreen;
	// Use this for initialization
	void Start () {
        
        ShowMainMenu();
        
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnUserInput(string input)
    {

        if (input.ToLower() == "menu")
        {
            ShowMainMenu();
        }
        else if (currentScreen == Screen.MainMenu)
        {
            RunMainMenu(input);
        }
        
    }

    void RunMainMenu(string input)
    {
        if (input == "1" || input == "2" || input == "3")
        {
            level = int.Parse(input);
            StartGame();
        }
        else if (input.ToLower() == "007")
        {
            Terminal.WriteLine("Choose a level Mr. Bond.");
        }
        else if (input.ToLower() == "egg")
        {
            Terminal.WriteLine("Easter Egg Found");
        }
        else
        {
            Terminal.WriteLine("Please choose a valid level");
        }
    }

    void ShowMainMenu()
    {
        currentScreen = Screen.MainMenu;
        Terminal.ClearScreen();
        Terminal.WriteLine("What would you like to hack into?");
        Terminal.WriteLine("Press 1 for local library");
        Terminal.WriteLine("Press 2 for police station");
        Terminal.WriteLine("Press 3 for NSA");
        Terminal.WriteLine("Enter your selection: ");
    }
    
   void StartGame()
    {
        currentScreen = Screen.Password;
        Terminal.WriteLine("You have chosen level " + level);
        Terminal.WriteLine("Please enter your password: ");
    }
}
